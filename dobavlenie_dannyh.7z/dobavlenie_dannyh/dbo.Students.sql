﻿CREATE TABLE [dbo].[Students] (
    [Id]      INT        NOT NULL IDENTITY,
    [Name]    NCHAR (10) NULL,
    [Surname] NCHAR (10) NULL,
    [Date]    DATETIME NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

